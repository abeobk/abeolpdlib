#include <opencv2/opencv.hpp>

#ifdef ABEO_LIB_COMPILE
#   define ABEO_LIB __attribute__((visibility("default")))
#else
#   define ABEO_LIB
#endif

struct Result{
    float error=1e6;
    float x,y,z,angle;
};


namespace abeo{
    class ABEO_LIB LaunchpadDetector{
    public:
        LaunchpadDetector(std::string const& dir) ;
        ~LaunchpadDetector();

        void setBlurRad(int rad);
        void setMeanRad(int rad);
        void setMeanC(int C);
        void setCircleMinLength(int min_len);
        void setCircleMaxError(double value);
        void setCircleMinRatio(double value);
        void setShowLog(bool show);
        Result detect(cv::Mat & img, bool draw_result=false)const;

    private:
        void* m_impl = nullptr;
    };
}
