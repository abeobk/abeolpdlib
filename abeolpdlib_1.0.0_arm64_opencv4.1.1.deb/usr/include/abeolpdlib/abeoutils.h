#include <chrono>
#include <iostream>
#include <sstream>
#include <vector>
#include <string>
#include <utility>
#include <fstream>
#include <map>
#include <stdexcept>
#include <cctype>
#include <algorithm>


using clk_t = std::chrono::steady_clock;

namespace abeo{

    class TicToc{
        public:
        //Create tictoc timer and start the timer
        TicToc(){tic();}

        //Start timer
        inline void tic(){t0=clk_t::now();}
        //Get current elapsed time
        inline double elapsed()const{
            auto t1= clk_t::now();
            auto dt = t1-t0;
            return std::chrono::duration_cast<std::chrono::microseconds>(dt).count()*0.001;
        }

        //Return elapsed time and reset timer
        inline double toc(){
            auto t=elapsed();
            tic();
            return t;
        }
        inline operator double(){return elapsed();}

        private:
        clk_t::time_point t0;
    };

    class PerformanceMonitor{
        public:

        PerformanceMonitor(std::string const& title){ title_=title; }
        //mark a time point
        inline void mark(std::string const& msg){ laps_.emplace_back(msg,tt_.elapsed()); }
        //clear laps
        inline void reset(){laps_.clear();tt_.tic();}
        //convert to string
        inline std::string toString()const{
            std::stringstream ss;

            ss<<title_<<"\n";
            //     000000.12  000000.12  ABCDEFGHIJKLMNO
            ss << "T(ms)      dt(ms)     Message\n";
            char buf[512];
            double t0=0;
            for(auto& lap:laps_){
                double t = lap.second;
                sprintf(buf,"%9.2f %9.2f %s\n",t, t-t0,lap.first.c_str());
                ss<<buf;
                t0=t;
            }

            ss << "TOTAL: " << t0 << "ms";

            return ss.str();
        }

        private:

        TicToc tt_;
        std::string title_;
        std::vector<std::pair<std::string, double>> laps_;
    };


    
    //USEFUL converters

    inline int to_int(std::string const& str, int default_value=0){ try{ return std::stoi(str); }catch(...){}return default_value; }
    inline double to_double(std::string const& str, double default_value=0){try{return std::stod(str);}catch(...){}return default_value;}
    inline bool to_bool(std::string const& str, bool default_value=false){return str=="true"||str=="TRUE"||str=="True";}

    template<class T>
    std::vector<T> to_arr_(std::string const& str, std::vector<T> default_value={}){
        try{
            std::vector<T> values;
            std::istringstream ss(str);
            T val;
            while(ss>>val)values.push_back(val);
            return values;
        }catch(...){}
        return std::move(default_value);
    }

    template<class T=int> T to_(std::string const& str, T default_value=T(0)){return to_int(str,default_value);}
    template<> double to_<double>(std::string const& str, double default_value){return to_double(str,default_value);}
    template<> float to_<float>(std::string const& str, float default_value){return to_double(str,default_value);}
    template<> bool to_<bool>(std::string const& str,bool default_value){return to_bool(str,default_value);}
    template<> std::vector<int> to_<std::vector<int>>(std::string const& str,std::vector<int> default_value){return to_arr_<int>(str,default_value);}
    template<> std::vector<double> to_<std::vector<double>>(std::string const& str,std::vector<double> default_value){return to_arr_<double>(str,default_value);}
    template<> std::vector<float> to_<std::vector<float>>(std::string const& str,std::vector<float> default_value){return to_arr_<float>(str,default_value);}
    template<> std::vector<bool> to_<std::vector<bool>>(std::string const& str,std::vector<bool> default_value){return to_arr_<bool>(str,default_value);}

    //trim string
    inline void ltrim(std::string&s){ s.erase(s.begin(),std::find_if(s.begin(),s.end(),[](char c){return !std::isspace(c);})); }
    inline void rtrim(std::string&s){ s.erase(std::find_if(s.rbegin(),s.rend(),[](char c){return !std::isspace(c);}).base(), s.end()); }
    inline void trim(std::string&s){ltrim(s);rtrim(s);}

    class Config{
    public:
        void read(std::string const& filename){
            map_.clear();
            std::string line;
            std::ifstream file;
            file.open(filename);
            if(file.is_open()){
                //read all lines
                while(std::getline(file,line)){
                    trim(line);
                    std::istringstream iss(line);
                    std::string key;
                    if(std::getline(iss,key,'=')){
                        trim(key);
                        if(key[0] == '#')continue;
                        std::string value;
                        if(std::getline(iss,value)){
                            trim(value);
                            map_[key] = value;
                        }
                    }
                }
            }
            else throw std::runtime_error(std::string("Failed to open config file! (") + filename+ std::string(")"));
        }

        std::string operator[](std::string const& key)const{
            auto it = map_.find(key);
            if(it == map_.end())return "";
            return it->second;
        }

        void print()const{
            std::cout<<"Configurations("<<map_.size()<<"){"<<std::endl;
            for(auto& it: map_){
                std::cout<<" ."<<it.first<<":"<<it.second<<std::endl;
            }
            std::cout<<"}"<<std::endl;
        }

    private:
        std::map<std::string, std::string> map_;
    };

}

